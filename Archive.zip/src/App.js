/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import "./css/App.scss";

import Header from "./components/Header";
import Footer from "./components/Footer";
import Sidebar from "./components/Sidebar";
import { InvestABI,InvestAddress,stakeToken_address,stakeABI} from "./config";

import Main from "./Pages/Main";

import Web3 from "web3";
const web3 = new Web3(Web3.givenProvider);

function App() {
  const [openSidebar, setOpenSidebar] = useState(false);
  const [openUserSidebar, setOpenUserSidebar] = useState(false);

  var activeUser = localStorage.getItem("_user");
  const [user, setUser] = useState(false);

  const [_address, setAddress] = useState(null);
  const [isWalletConnected, setisWalletConnected] = useState(false);
  const [IDs, setNetworkID] = useState(false);

  const [totlaInvestment, setTotalInvestment] = useState(0);
  const [totalReward, setwithrawableAmount] = useState("0");
  const [ref_data, set_Ref_data] = useState("0");
  const [ref_data1, set_Ref_data1] = useState("0");
  const [balance, setBalance] = useState(0);


  const [totalbusiness, setbusiness] = useState("0");
  const [minStake, setminStake] = useState("0");
  const [maxStake, setmaxStake] = useState("0");

  const [totalReferrals, settotalReferrals] = useState(0);
  const [referral, setReferral] = useState("0");
  const [ref_from, set_ref_from] = useState("0");

  // const [user, setUser] = useState("Connect your wallet");

  const CHAIN_ID = "3";
  const CHAIN_ID1 = "0x3";

  async function connectWallet() {
    if (!window.ethereum) {
      alert(
        "it looks like that you dont have metamask installed,please install"
      );
      return;
    }

    try {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      });
      const networkId = await window.ethereum.request({
        method: "net_version",
      });
      setNetworkID(networkId);
      console.log(
        "id from async func is: " + CHAIN_ID + "hellggg " + networkId.toString()
      );

      // console.log(IDs)
      if (networkId == CHAIN_ID) {
        setisWalletConnected(true);
        console.log("its in net" + isWalletConnected);

        setAddress(window.ethereum.selectedAddress);
        return accounts[0].toString();
      } else {
        window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: CHAIN_ID1 }],
        });
      }
    } catch (err) {
      alert("Somethineeeeeg went wrong.");
    }
  }

  useEffect(() => {
    // connectWallet();
    // mount();
  }, []);



  async function mount() {
    try {
      // Get network provider and web3 instance.
      const web3 = new Web3(window.ethereum);

      // Use web3 to get the user's accounts.
      const accounts = await web3.eth.getAccounts();

      // Get the contract instance.
      const networkId = await web3.eth.net.getId();
      // const tokenContract = tokenContractAddress;
      //const investContract = InvestAddress;

      const contract = new web3.eth.Contract(InvestABI, InvestAddress);
      let totalReward = await contract.methods
        .getReward()
        .call({ from: accounts[0].toString() });
      var ref_data = await contract.methods
        .referralLevel_earning()
        .call({ from: accounts[0].toString() });
      let min_stake =await contract.methods.min_Stake_amount().call();
      let max_stake =await contract.methods.max_Stake_amount().call();

      const ref_data1 = await contract.methods
        .referralLevel_count()
        .call({ from: accounts[0].toString() });
      const contract1 = new web3.eth.Contract(stakeABI, stakeToken_address);
      // ref_data=web3.utils.fromWei(ref_data,"ether");

      let balance = await contract1.methods.balanceOf(accounts[0]).call();
      // for(let i=0;i<20;i++)
      // {

      // }

      const ref_from = await contract.methods
        .DUSDinvestor(accounts[0].toString())
        .call();

      const totalStakes = await contract.methods.totalDUSDInvestors().call(); //get stake
      const totalInvest = await contract.methods
        .getTotalInvestmentDUSD()
        .call({ from: accounts[0].toString() });
        



        const business = await contract.methods
        .totalbusiness()
        .call({ from: accounts[0].toString() });
      const totalReferral = await contract.methods
        .DUSDTotalReferrals()
        .call({ from: accounts[0].toString() });
      balance = balance/10**8;
      totalReward = web3.utils.fromWei(totalReward, "ether");

      console.log("hiiii" + balance);
   

      setTotalInvestment(totalInvest);
      setwithrawableAmount(totalReward);
      setminStake(min_stake);
      setmaxStake(max_stake)

      setBalance(balance);
      setisWalletConnected(true);
      setAddress(window.ethereum.selectedAddress);
      setbusiness(business);
      settotalReferrals(totalReferral);
      set_Ref_data(ref_data);
      set_Ref_data1(ref_data1);
      set_ref_from(ref_from[0]);
      setUser(accounts[0]);
      // Set web3, accounts, and contract to the state, and then proceed with an
      // example of interacting with the contract's methods.
      //this.setState({ web3, accounts, contract: instance }, this.runExample);
    } catch (error) {
      // Catch any errors for any of the above operations.

      console.error(error);
    }
  }

  async function stake(investment) {
    if (investment > 0) {
      try {
        let web3;
        // Get network provider and web3 instance.
        if (window.ethereum) {
          web3 = new Web3(window.ethereum);
          const id = await window.ethereum.request({ method: "eth_chainId" });
          console.log(
            "id from async func is: " + CHAIN_ID + "hello" + id.toString()
          );
          if (CHAIN_ID != id.toString()) {
            console.log("done");
            alert("please change your network to binance smart chain");
            return;
          }
        } else {
          alert(
            "its look like you dont have metmask extension installed in you browser"
          );
          return;
        }

        // Use web3 to get the user's accounts.
        const accounts = await web3.eth.getAccounts();

        // Get the contract instance.
        const networkId = await web3.eth.net.getId();
        // const tokenContract = tokenContractAddress;
        //const investContract = InvestAddress;

        if (referral == "0") {
          const contract = new web3.eth.Contract(InvestABI, InvestAddress);
          const result = await contract.methods
            .Stake(investment, 12)
            .send({ from: accounts[0] });
          if (result) {
            alert("Your investment is successfully done");
            mount();
          }
        } else {
          const contract = new web3.eth.Contract(InvestABI, InvestAddress);
          const result = await contract.methods
            .Stake(investment, referral)
            .send({ from: accounts[0] });
          if (result) {
            alert("Your investment is successfully done");
            mount();
          }
        }
      } catch (error) {
        // Catch any errors for any of the above operations.
        alert(
          `Failed to load web3, accounts, or contract. Check console for details.`
        );
        console.error(error);
      }
    } else if (investment <= 0 || investment == "") {
      alert("please write amount ");
    }
  }
  window.ethereum.on("chainChanged", hello);
  window.ethereum.on("accountsChanged", hello);

  function hello() {
    window.location.reload();
  }

  async function WithdrawReward() {
    try {
      let web3;
      // Get network provider and web3 instance.
      if (window.ethereum) {
        web3 = new Web3(window.ethereum);
        const id = await window.ethereum.request({ method: "eth_chainId" });
        console.log("id from async func is: " + id);
        if (CHAIN_ID != id.toString()) {
          alert("please change your network to Ropsten");
          return;
        }
      } else {
        alert(
          "its look like you dont have metmask extension installed in you browser"
        );
        return;
      }

      // Use web3 to get the user's accounts.
      const accounts = await web3.eth.getAccounts();

      // Get the contract instance.
      const networkId = await web3.eth.net.getId();
      // const tokenContract = tokenContractAddress;
      //const investContract = InvestAddress;

      const contract = new web3.eth.Contract(InvestABI, InvestAddress);

      const result = await contract.methods
        .withdrawReward()
        .send({ from: accounts[0] });
      if (result) {
        alert("your investment is successfully done");
        mount();
      }
    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`
      );
      console.error(error);
    }
  }

  return (
    <div className="App">
      {/* <BrowserRouter> */}
      <Sidebar openSidebar={openSidebar} setOpenSidebar={setOpenSidebar} />
      {/* <Header openSidebar={openSidebar} setOpenSidebar={setOpenSidebar} connectWallet={connectWallet} /> */}
      <Routes>
        <Route path="/" element={<Main />} exact />
      </Routes>
      {/* <Footer /> */}
      {/* </BrowserRouter> */}
    </div>
  );
}

export default App;
